function mensaje(){
    alert("Correo: osw.mg935@gmail.com");
}